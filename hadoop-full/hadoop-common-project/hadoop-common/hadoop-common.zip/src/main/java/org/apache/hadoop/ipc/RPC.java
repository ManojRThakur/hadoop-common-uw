/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.hadoop.ipc;

import ostrusted.quals.OsUntrusted;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.io.*;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.net.SocketFactory;

import org.apache.commons.logging.*;

import org.apache.hadoop.HadoopIllegalArgumentException;
import org.apache.hadoop.io.*;
import org.apache.hadoop.io.retry.RetryPolicy;
import org.apache.hadoop.ipc.Client.ConnectionId;
import org.apache.hadoop.ipc.protobuf.ProtocolInfoProtos.ProtocolInfoService;
import org.apache.hadoop.ipc.protobuf.RpcHeaderProtos.RpcResponseHeaderProto.RpcErrorCodeProto;
import org.apache.hadoop.ipc.protobuf.RpcHeaderProtos.RpcResponseHeaderProto.RpcStatusProto;
import org.apache.hadoop.net.NetUtils;
import org.apache.hadoop.security.SaslRpcServer;
import org.apache.hadoop.security.UserGroupInformation;
import org.apache.hadoop.security.token.SecretManager;
import org.apache.hadoop.security.token.TokenIdentifier;
import org.apache.hadoop.classification.InterfaceAudience;
import org.apache.hadoop.classification.InterfaceStability;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.ReflectionUtils;
import org.apache.hadoop.util.Time;

import com.google.protobuf.BlockingService;

/** A simple RPC mechanism.
 *
 * A <i>protocol</i> is a Java interface.  All parameters and return types must
 * be one of:
 *
 * <ul> <li>a primitive type, <code>boolean</code>, <code>byte</code>,
 * <code>char</code>, <code>short</code>, <code>int</code>, <code>long</code>,
 * <code>float</code>, <code>double</code>, or <code>void</code>; or</li>
 *
 * <li>a {@link String}; or</li>
 *
 * <li>a {@link Writable}; or</li>
 *
 * <li>an array of the above types</li> </ul>
 *
 * All methods in the protocol should throw only IOException.  No field data of
 * the protocol instance is transmitted.
 */
@InterfaceAudience.LimitedPrivate(value = { "Common", "HDFS", "MapReduce", "Yarn" })
@InterfaceStability.Evolving
public class RPC {
  final static @OsUntrusted int RPC_SERVICE_CLASS_DEFAULT = 0;
  public enum RpcKind {

@OsUntrusted  RPC_BUILTIN ((@OsUntrusted short) 1),         // Used for built in calls by tests

@OsUntrusted  RPC_WRITABLE ((@OsUntrusted short) 2),        // Use WritableRpcEngine

@OsUntrusted  RPC_PROTOCOL_BUFFER ((@OsUntrusted short) 3); // Use ProtobufRpcEngine
    final static @OsUntrusted short MAX_INDEX = RPC_PROTOCOL_BUFFER.value; // used for array size
    public final @OsUntrusted short value; //TODO make it private

    @OsUntrusted
    RpcKind(@OsUntrusted short val) {
      this.value = val;
    } 
  }
  
  interface RpcInvoker {   
    /**
     * Process a client call on the server side
     * @param server the server within whose context this rpc call is made
     * @param protocol - the protocol name (the class of the client proxy
     *      used to make calls to the rpc server.
     * @param rpcRequest  - deserialized
     * @param receiveTime time at which the call received (for metrics)
     * @return the call's return
     * @throws IOException
     **/
    public @OsUntrusted Writable call(RPC.@OsUntrusted RpcInvoker this, @OsUntrusted Server server, @OsUntrusted String protocol,
        @OsUntrusted
        Writable rpcRequest, @OsUntrusted long receiveTime) throws Exception ;
  }
  
  static final @OsUntrusted Log LOG = LogFactory.getLog(RPC.class);
  
  /**
   * Get all superInterfaces that extend VersionedProtocol
   * @param childInterfaces
   * @return the super interfaces that extend VersionedProtocol
   */
  static @OsUntrusted Class<@OsUntrusted ?> @OsUntrusted [] getSuperInterfaces(Class<?>[] childInterfaces) {
    @OsUntrusted
    List<@OsUntrusted Class<@OsUntrusted ?>> allInterfaces = new @OsUntrusted ArrayList<@OsUntrusted Class<@OsUntrusted ?>>();

    for (@OsUntrusted Class<@OsUntrusted ?> childInterface : childInterfaces) {
      if (VersionedProtocol.class.isAssignableFrom(childInterface)) {
          allInterfaces.add(childInterface);
          allInterfaces.addAll(
              Arrays.asList(
                  getSuperInterfaces(childInterface.getInterfaces())));
      } else {
        LOG.warn("Interface " + childInterface +
              " ignored because it does not extend VersionedProtocol");
      }
    }
    return allInterfaces.toArray(new @OsUntrusted Class @OsUntrusted [allInterfaces.size()]);
  }
  
  /**
   * Get all interfaces that the given protocol implements or extends
   * which are assignable from VersionedProtocol.
   */
  static @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> @OsUntrusted [] getProtocolInterfaces(@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol) {
    @OsUntrusted
    Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> @OsUntrusted [] interfaces  = protocol.getInterfaces();
    return getSuperInterfaces(interfaces);
  }
  
  /**
   * Get the protocol name.
   *  If the protocol class has a ProtocolAnnotation, then get the protocol
   *  name from the annotation; otherwise the class name is the protocol name.
   */
  static public @OsUntrusted String getProtocolName(@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol) {
    if (protocol == null) {
      return null;
    }
    @OsUntrusted
    ProtocolInfo anno = protocol.getAnnotation(ProtocolInfo.class);
    return  (anno == null) ? protocol.getName() : anno.protocolName();
  }
  
  /**
   * Get the protocol version from protocol class.
   * If the protocol class has a ProtocolAnnotation, then get the protocol
   * name from the annotation; otherwise the class name is the protocol name.
   */
  static public @OsUntrusted long getProtocolVersion(@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol) {
    if (protocol == null) {
      throw new @OsUntrusted IllegalArgumentException("Null protocol");
    }
    @OsUntrusted
    long version;
    @OsUntrusted
    ProtocolInfo anno = protocol.getAnnotation(ProtocolInfo.class);
    if (anno != null) {
      version = anno.protocolVersion();
      if (version != -1)
        return version;
    }
    try {
      @OsUntrusted
      Field versionField = protocol.getField("versionID");
      versionField.setAccessible(true);
      return versionField.getLong(protocol);
    } catch (@OsUntrusted NoSuchFieldException ex) {
      throw new @OsUntrusted RuntimeException(ex);
    } catch (@OsUntrusted IllegalAccessException ex) {
      throw new @OsUntrusted RuntimeException(ex);
    }
  }

  private @OsUntrusted RPC() {}                                  // no public ctor

  // cache of RpcEngines by protocol
  private static final @OsUntrusted Map<@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object>, @OsUntrusted RpcEngine> PROTOCOL_ENGINES
    = new @OsUntrusted HashMap<@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object>, @OsUntrusted RpcEngine>();

  private static final @OsUntrusted String ENGINE_PROP = "rpc.engine";

  /**
   * Set a protocol to use a non-default RpcEngine.
   * @param conf configuration to use
   * @param protocol the protocol interface
   * @param engine the RpcEngine impl
   */
  public static void setProtocolEngine(@OsUntrusted Configuration conf,
                                @OsUntrusted
                                Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol, @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> engine) {
    conf.setClass(ENGINE_PROP+"."+protocol.getName(), engine, RpcEngine.class);
  }

  // return the RpcEngine configured to handle a protocol
  static synchronized @OsUntrusted RpcEngine getProtocolEngine(@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol,
      @OsUntrusted
      Configuration conf) {
    @OsUntrusted
    RpcEngine engine = PROTOCOL_ENGINES.get(protocol);
    if (engine == null) {
      @OsUntrusted
      Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> impl = conf.getClass(ENGINE_PROP+"."+protocol.getName(),
                                    WritableRpcEngine.class);
      engine = (@OsUntrusted RpcEngine)ReflectionUtils.newInstance(impl, conf);
      PROTOCOL_ENGINES.put(protocol, engine);
    }
    return engine;
  }

  /**
   * A version mismatch for the RPC protocol.
   */
  public static class VersionMismatch extends @OsUntrusted RpcServerException {
    private static final @OsUntrusted long serialVersionUID = 0;

    private @OsUntrusted String interfaceName;
    private @OsUntrusted long clientVersion;
    private @OsUntrusted long serverVersion;
    
    /**
     * Create a version mismatch exception
     * @param interfaceName the name of the protocol mismatch
     * @param clientVersion the client's version of the protocol
     * @param serverVersion the server's version of the protocol
     */
    public @OsUntrusted VersionMismatch(@OsUntrusted String interfaceName, @OsUntrusted long clientVersion,
                           @OsUntrusted
                           long serverVersion) {
      super("Protocol " + interfaceName + " version mismatch. (client = " +
            clientVersion + ", server = " + serverVersion + ")");
      this.interfaceName = interfaceName;
      this.clientVersion = clientVersion;
      this.serverVersion = serverVersion;
    }
    
    /**
     * Get the interface name
     * @return the java class name 
     *          (eg. org.apache.hadoop.mapred.InterTrackerProtocol)
     */
    public @OsUntrusted String getInterfaceName(RPC.@OsUntrusted VersionMismatch this) {
      return interfaceName;
    }
    
    /**
     * Get the client's preferred version
     */
    public @OsUntrusted long getClientVersion(RPC.@OsUntrusted VersionMismatch this) {
      return clientVersion;
    }
    
    /**
     * Get the server's agreed to version.
     */
    public @OsUntrusted long getServerVersion(RPC.@OsUntrusted VersionMismatch this) {
      return serverVersion;
    }
    /**
     * get the rpc status corresponding to this exception
     */
    public @OsUntrusted RpcStatusProto getRpcStatusProto(RPC.@OsUntrusted VersionMismatch this) {
      return RpcStatusProto.ERROR;
    }

    /**
     * get the detailed rpc status corresponding to this exception
     */
    public @OsUntrusted RpcErrorCodeProto getRpcErrorCodeProto(RPC.@OsUntrusted VersionMismatch this) {
      return RpcErrorCodeProto.ERROR_RPC_VERSION_MISMATCH;
    }
  }

  /**
   * Get a proxy connection to a remote server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @return the proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T waitForProxy(
      @OsUntrusted
      Class<@OsUntrusted T> protocol,
      @OsUntrusted
      long clientVersion,
      @OsUntrusted
      InetSocketAddress addr,
      @OsUntrusted
      Configuration conf
      ) throws IOException {
    return waitForProtocolProxy(protocol, clientVersion, addr, conf).getProxy();
  }

  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @return the protocol proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> waitForProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                             @OsUntrusted
                             long clientVersion,
                             @OsUntrusted
                             InetSocketAddress addr,
                             @OsUntrusted
                             Configuration conf) throws IOException {
    return waitForProtocolProxy(
        protocol, clientVersion, addr, conf, Long.MAX_VALUE);
  }

  /**
   * Get a proxy connection to a remote server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @param connTimeout time in milliseconds before giving up
   * @return the proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T waitForProxy(@OsUntrusted Class<@OsUntrusted T> protocol, @OsUntrusted long clientVersion,
                             @OsUntrusted
                             InetSocketAddress addr, @OsUntrusted Configuration conf,
                             @OsUntrusted
                             long connTimeout) throws IOException { 
    return waitForProtocolProxy(protocol, clientVersion, addr,
        conf, connTimeout).getProxy();
  }

  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @param connTimeout time in milliseconds before giving up
   * @return the protocol proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> waitForProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                             @OsUntrusted
                             long clientVersion,
                             @OsUntrusted
                             InetSocketAddress addr, @OsUntrusted Configuration conf,
                             @OsUntrusted
                             long connTimeout) throws IOException { 
    return waitForProtocolProxy(protocol, clientVersion, addr, conf, 0, null, connTimeout);
  }
  
  /**
   * Get a proxy connection to a remote server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @param rpcTimeout timeout for each RPC
   * @param timeout time in milliseconds before giving up
   * @return the proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T waitForProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                             @OsUntrusted
                             long clientVersion,
                             @OsUntrusted
                             InetSocketAddress addr, @OsUntrusted Configuration conf,
                             @OsUntrusted
                             int rpcTimeout,
                             @OsUntrusted
                             long timeout) throws IOException {
    return waitForProtocolProxy(protocol, clientVersion, addr,
        conf, rpcTimeout, null, timeout).getProxy();
  }

  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @param rpcTimeout timeout for each RPC
   * @param timeout time in milliseconds before giving up
   * @return the proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> waitForProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                               @OsUntrusted
                               long clientVersion,
                               @OsUntrusted
                               InetSocketAddress addr, @OsUntrusted Configuration conf,
                               @OsUntrusted
                               int rpcTimeout,
                               @OsUntrusted
                               RetryPolicy connectionRetryPolicy,
                               @OsUntrusted
                               long timeout) throws IOException { 
    @OsUntrusted
    long startTime = Time.now();
    @OsUntrusted
    IOException ioe;
    while (true) {
      try {
        return getProtocolProxy(protocol, clientVersion, addr, 
            UserGroupInformation.getCurrentUser(), conf, NetUtils
            .getDefaultSocketFactory(conf), rpcTimeout, connectionRetryPolicy);
      } catch(@OsUntrusted ConnectException se) {  // namenode has not been started
        LOG.info("Server at " + addr + " not available yet, Zzzzz...");
        ioe = se;
      } catch(@OsUntrusted SocketTimeoutException te) {  // namenode is busy
        LOG.info("Problem connecting to server: " + addr);
        ioe = te;
      } catch(@OsUntrusted NoRouteToHostException nrthe) { // perhaps a VIP is failing over
        LOG.info("No route to host for server: " + addr);
        ioe = nrthe;
      }
      // check if timed out
      if (Time.now()-timeout >= startTime) {
        throw ioe;
      }

      // wait for retry
      try {
        Thread.sleep(1000);
      } catch (@OsUntrusted InterruptedException ie) {
        // IGNORE
      }
    }
  }

  /** Construct a client-side proxy object that implements the named protocol,
   * talking to a server at the named address. 
   * @param <T>*/
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T getProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr, @OsUntrusted Configuration conf,
                                @OsUntrusted
                                SocketFactory factory) throws IOException {
    return getProtocolProxy(
        protocol, clientVersion, addr, conf, factory).getProxy();
  }

  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param conf configuration to use
   * @param factory socket factory
   * @return the protocol proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> getProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr, @OsUntrusted Configuration conf,
                                @OsUntrusted
                                SocketFactory factory) throws IOException {
    @OsUntrusted
    UserGroupInformation ugi = UserGroupInformation.getCurrentUser();
    return getProtocolProxy(protocol, clientVersion, addr, ugi, conf, factory);
  }
  
  /** Construct a client-side proxy object that implements the named protocol,
   * talking to a server at the named address. 
   * @param <T>*/
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T getProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr,
                                @OsUntrusted
                                UserGroupInformation ticket,
                                @OsUntrusted
                                Configuration conf,
                                @OsUntrusted
                                SocketFactory factory) throws IOException {
    return getProtocolProxy(
        protocol, clientVersion, addr, ticket, conf, factory).getProxy();
  }

  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol class
   * @param clientVersion client version
   * @param addr remote address
   * @param ticket user group information
   * @param conf configuration to use
   * @param factory socket factory
   * @return the protocol proxy
   * @throws IOException if the far end through a RemoteException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> getProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr,
                                @OsUntrusted
                                UserGroupInformation ticket,
                                @OsUntrusted
                                Configuration conf,
                                @OsUntrusted
                                SocketFactory factory) throws IOException {
    return getProtocolProxy(
        protocol, clientVersion, addr, ticket, conf, factory, 0, null);
  }
  
  /**
   * Construct a client-side proxy that implements the named protocol,
   * talking to a server at the named address.
   * @param <T>
   * 
   * @param protocol protocol
   * @param clientVersion client's version
   * @param addr server address
   * @param ticket security ticket
   * @param conf configuration
   * @param factory socket factory
   * @param rpcTimeout max time for each rpc; 0 means no timeout
   * @return the proxy
   * @throws IOException if any error occurs
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T getProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr,
                                @OsUntrusted
                                UserGroupInformation ticket,
                                @OsUntrusted
                                Configuration conf,
                                @OsUntrusted
                                SocketFactory factory,
                                @OsUntrusted
                                int rpcTimeout) throws IOException {
    return getProtocolProxy(protocol, clientVersion, addr, ticket,
             conf, factory, rpcTimeout, null).getProxy();
  }
  
  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol protocol
   * @param clientVersion client's version
   * @param addr server address
   * @param ticket security ticket
   * @param conf configuration
   * @param factory socket factory
   * @param rpcTimeout max time for each rpc; 0 means no timeout
   * @return the proxy
   * @throws IOException if any error occurs
   */
   public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> getProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr,
                                @OsUntrusted
                                UserGroupInformation ticket,
                                @OsUntrusted
                                Configuration conf,
                                @OsUntrusted
                                SocketFactory factory,
                                @OsUntrusted
                                int rpcTimeout,
                                @OsUntrusted
                                RetryPolicy connectionRetryPolicy) throws IOException {    
    if (UserGroupInformation.isSecurityEnabled()) {
      SaslRpcServer.init(conf);
    }
    return getProtocolEngine(protocol,conf).getProxy(protocol, clientVersion,
        addr, ticket, conf, factory, rpcTimeout, connectionRetryPolicy);
  }

   /**
    * Construct a client-side proxy object with the default SocketFactory
    * @param <T>
    * 
    * @param protocol
    * @param clientVersion
    * @param addr
    * @param conf
    * @return a proxy instance
    * @throws IOException
    */
   public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted T getProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                 @OsUntrusted
                                 long clientVersion,
                                 @OsUntrusted
                                 InetSocketAddress addr, @OsUntrusted Configuration conf)
     throws IOException {

     return getProtocolProxy(protocol, clientVersion, addr, conf).getProxy();
   }
  
  /**
   * Returns the server address for a given proxy.
   */
  public static @OsUntrusted InetSocketAddress getServerAddress(@OsUntrusted Object proxy) {
    return getConnectionIdForProxy(proxy).getAddress();
  }

  /**
   * Return the connection ID of the given object. If the provided object is in
   * fact a protocol translator, we'll get the connection ID of the underlying
   * proxy object.
   * 
   * @param proxy the proxy object to get the connection ID of.
   * @return the connection ID for the provided proxy object.
   */
  public static @OsUntrusted ConnectionId getConnectionIdForProxy(@OsUntrusted Object proxy) {
    if (proxy instanceof @OsUntrusted ProtocolTranslator) {
      proxy = ((@OsUntrusted ProtocolTranslator)proxy).getUnderlyingProxyObject();
    }
    @OsUntrusted
    RpcInvocationHandler inv = (@OsUntrusted RpcInvocationHandler) Proxy
        .getInvocationHandler(proxy);
    return inv.getConnectionId();
  }
   
  /**
   * Get a protocol proxy that contains a proxy connection to a remote server
   * and a set of methods that are supported by the server
   * 
   * @param protocol
   * @param clientVersion
   * @param addr
   * @param conf
   * @return a protocol proxy
   * @throws IOException
   */
  public static <@OsUntrusted T extends java.lang.@OsUntrusted Object> @OsUntrusted ProtocolProxy<@OsUntrusted T> getProtocolProxy(@OsUntrusted Class<@OsUntrusted T> protocol,
                                @OsUntrusted
                                long clientVersion,
                                @OsUntrusted
                                InetSocketAddress addr, @OsUntrusted Configuration conf)
    throws IOException {

    return getProtocolProxy(protocol, clientVersion, addr, conf, NetUtils
        .getDefaultSocketFactory(conf));
  }

  /**
   * Stop the proxy. Proxy must either implement {@link Closeable} or must have
   * associated {@link RpcInvocationHandler}.
   * 
   * @param proxy
   *          the RPC proxy object to be stopped
   * @throws HadoopIllegalArgumentException
   *           if the proxy does not implement {@link Closeable} interface or
   *           does not have closeable {@link InvocationHandler}
   */
  public static void stopProxy(@OsUntrusted Object proxy) {
    if (proxy == null) {
      throw new @OsUntrusted HadoopIllegalArgumentException(
          "Cannot close proxy since it is null");
    }
    try {
      if (proxy instanceof @OsUntrusted Closeable) {
        ((@OsUntrusted Closeable) proxy).close();
        return;
      } else {
        @OsUntrusted
        InvocationHandler handler = Proxy.getInvocationHandler(proxy);
        if (handler instanceof @OsUntrusted Closeable) {
          ((@OsUntrusted Closeable) handler).close();
          return;
        }
      }
    } catch (@OsUntrusted IOException e) {
      LOG.error("Closing proxy or invocation handler caused exception", e);
    } catch (@OsUntrusted IllegalArgumentException e) {
      LOG.error("RPC.stopProxy called on non proxy.", e);
    }
    
    // If you see this error on a mock object in a unit test you're
    // developing, make sure to use MockitoUtil.mockProtocol() to
    // create your mock.
    throw new @OsUntrusted HadoopIllegalArgumentException(
        "Cannot close proxy - is not Closeable or "
            + "does not provide closeable invocation handler "
            + proxy.getClass());
  }

  /**
   * Class to construct instances of RPC server with specific options.
   */
  public static class Builder {
    private @OsUntrusted Class<@OsUntrusted ?> protocol = null;
    private @OsUntrusted Object instance = null;
    private @OsUntrusted String bindAddress = "0.0.0.0";
    private @OsUntrusted int port = 0;
    private @OsUntrusted int numHandlers = 1;
    private @OsUntrusted int numReaders = -1;
    private @OsUntrusted int queueSizePerHandler = -1;
    private @OsUntrusted boolean verbose = false;
    private final @OsUntrusted Configuration conf;    
    private @OsUntrusted SecretManager<@OsUntrusted ? extends @OsUntrusted TokenIdentifier> secretManager = null;
    private @OsUntrusted String portRangeConfig = null;
    
    public @OsUntrusted Builder(@OsUntrusted Configuration conf) {
      this.conf = conf;
    }

    /** Mandatory field */
    public @OsUntrusted Builder setProtocol(RPC.@OsUntrusted Builder this, @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocol) {
      this.protocol = protocol;
      return this;
    }
    
    /** Mandatory field */
    public @OsUntrusted Builder setInstance(RPC.@OsUntrusted Builder this, @OsUntrusted Object instance) {
      this.instance = instance;
      return this;
    }
    
    /** Default: 0.0.0.0 */
    public @OsUntrusted Builder setBindAddress(RPC.@OsUntrusted Builder this, @OsUntrusted String bindAddress) {
      this.bindAddress = bindAddress;
      return this;
    }
    
    /** Default: 0 */
    public @OsUntrusted Builder setPort(RPC.@OsUntrusted Builder this, @OsUntrusted int port) {
      this.port = port;
      return this;
    }
    
    /** Default: 1 */
    public @OsUntrusted Builder setNumHandlers(RPC.@OsUntrusted Builder this, @OsUntrusted int numHandlers) {
      this.numHandlers = numHandlers;
      return this;
    }
    
    /** Default: -1 */
    public @OsUntrusted Builder setnumReaders(RPC.@OsUntrusted Builder this, @OsUntrusted int numReaders) {
      this.numReaders = numReaders;
      return this;
    }
    
    /** Default: -1 */
    public @OsUntrusted Builder setQueueSizePerHandler(RPC.@OsUntrusted Builder this, @OsUntrusted int queueSizePerHandler) {
      this.queueSizePerHandler = queueSizePerHandler;
      return this;
    }
    
    /** Default: false */
    public @OsUntrusted Builder setVerbose(RPC.@OsUntrusted Builder this, @OsUntrusted boolean verbose) {
      this.verbose = verbose;
      return this;
    }
    
    /** Default: null */
    public @OsUntrusted Builder setSecretManager(
        RPC.@OsUntrusted Builder this, @OsUntrusted
        SecretManager<@OsUntrusted ? extends @OsUntrusted TokenIdentifier> secretManager) {
      this.secretManager = secretManager;
      return this;
    }
    
    /** Default: null */
    public @OsUntrusted Builder setPortRangeConfig(RPC.@OsUntrusted Builder this, @OsUntrusted String portRangeConfig) {
      this.portRangeConfig = portRangeConfig;
      return this;
    }
    
    /**
     * Build the RPC Server. 
     * @throws IOException on error
     * @throws HadoopIllegalArgumentException when mandatory fields are not set
     */
    public @OsUntrusted Server build(RPC.@OsUntrusted Builder this) throws IOException, HadoopIllegalArgumentException {
      if (this.conf == null) {
        throw new @OsUntrusted HadoopIllegalArgumentException("conf is not set");
      }
      if (this.protocol == null) {
        throw new @OsUntrusted HadoopIllegalArgumentException("protocol is not set");
      }
      if (this.instance == null) {
        throw new @OsUntrusted HadoopIllegalArgumentException("instance is not set");
      }
      
      return getProtocolEngine(this.protocol, this.conf).getServer(
          this.protocol, this.instance, this.bindAddress, this.port,
          this.numHandlers, this.numReaders, this.queueSizePerHandler,
          this.verbose, this.conf, this.secretManager, this.portRangeConfig);
    }
  }
  
  /** An RPC Server. */
  public abstract static class Server extends org.apache.hadoop.ipc.Server {
   @OsUntrusted
   boolean verbose;
   static @OsUntrusted String classNameBase(@OsUntrusted String className) {
      @OsUntrusted
      String @OsUntrusted [] names = className.split("\\.", -1);
      if (names == null || names.length == 0) {
        return className;
      }
      return names[names.length-1];
    }
   
   /**
    * Store a map of protocol and version to its implementation
    */
   /**
    *  The key in Map
    */
   static class ProtoNameVer {
     final @OsUntrusted String protocol;
     final @OsUntrusted long   version;
     @OsUntrusted
     ProtoNameVer(@OsUntrusted String protocol, @OsUntrusted long ver) {
       this.protocol = protocol;
       this.version = ver;
     }
     @Override
     public @OsUntrusted boolean equals(RPC.Server.@OsUntrusted ProtoNameVer this, @OsUntrusted Object o) {
       if (o == null) 
         return false;
       if (this == o) 
         return true;
       if (! (o instanceof @OsUntrusted ProtoNameVer))
         return false;
       @OsUntrusted
       ProtoNameVer pv = (@OsUntrusted ProtoNameVer) o;
       return ((pv.protocol.equals(this.protocol)) && 
           (pv.version == this.version));     
     }
     @Override
     public @OsUntrusted int hashCode(RPC.Server.@OsUntrusted ProtoNameVer this) {
       return protocol.hashCode() * 37 + (@OsUntrusted int) version;    
     }
   }
   
   /**
    * The value in map
    */
   static class ProtoClassProtoImpl {
     final @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocolClass;
     final @OsUntrusted Object protocolImpl; 
     @OsUntrusted
     ProtoClassProtoImpl(@OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocolClass, @OsUntrusted Object protocolImpl) {
       this.protocolClass = protocolClass;
       this.protocolImpl = protocolImpl;
     }
   }

   @OsUntrusted
   ArrayList<@OsUntrusted Map<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl>> protocolImplMapArray = 
       new @OsUntrusted ArrayList<@OsUntrusted Map<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl>>(RpcKind.MAX_INDEX);
   
   @OsUntrusted
   Map<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl> getProtocolImplMap(RPC.@OsUntrusted Server this, RPC.@OsUntrusted RpcKind rpcKind) {
     if (protocolImplMapArray.size() == 0) {// initialize for all rpc kinds
       for (@OsUntrusted int i=0; i <= RpcKind.MAX_INDEX; ++i) {
         protocolImplMapArray.add(
             new @OsUntrusted HashMap<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl>(10));
       }
     }
     return protocolImplMapArray.get(rpcKind.ordinal());   
   }
   
   // Register  protocol and its impl for rpc calls
   void registerProtocolAndImpl(RPC.@OsUntrusted Server this, @OsUntrusted RpcKind rpcKind, @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocolClass, 
       @OsUntrusted
       Object protocolImpl) {
     @OsUntrusted
     String protocolName = RPC.getProtocolName(protocolClass);
     @OsUntrusted
     long version;
     

     try {
       version = RPC.getProtocolVersion(protocolClass);
     } catch (@OsUntrusted Exception ex) {
       LOG.warn("Protocol "  + protocolClass + 
            " NOT registered as cannot get protocol version ");
       return;
     }


     getProtocolImplMap(rpcKind).put(new @OsUntrusted ProtoNameVer(protocolName, version),
         new @OsUntrusted ProtoClassProtoImpl(protocolClass, protocolImpl)); 
     LOG.debug("RpcKind = " + rpcKind + " Protocol Name = " + protocolName +  " version=" + version +
         " ProtocolImpl=" + protocolImpl.getClass().getName() + 
         " protocolClass=" + protocolClass.getName());
   }
   
   static class VerProtocolImpl {
     final @OsUntrusted long version;
     final @OsUntrusted ProtoClassProtoImpl protocolTarget;
     @OsUntrusted
     VerProtocolImpl(@OsUntrusted long ver, @OsUntrusted ProtoClassProtoImpl protocolTarget) {
       this.version = ver;
       this.protocolTarget = protocolTarget;
     }
   }
   
   @OsUntrusted
   VerProtocolImpl @OsUntrusted [] getSupportedProtocolVersions(RPC.@OsUntrusted Server this, RPC.@OsUntrusted RpcKind rpcKind,
       @OsUntrusted
       String protocolName) {
     @OsUntrusted
     VerProtocolImpl @OsUntrusted [] resultk = 
         new  @OsUntrusted VerProtocolImpl @OsUntrusted [getProtocolImplMap(rpcKind).size()];
     @OsUntrusted
     int i = 0;
     for (Map.@OsUntrusted Entry<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl> pv :
                                       getProtocolImplMap(rpcKind).entrySet()) {
       if (pv.getKey().protocol.equals(protocolName)) {
         resultk[i++] = 
             new @OsUntrusted VerProtocolImpl(pv.getKey().version, pv.getValue());
       }
     }
     if (i == 0) {
       return null;
     }
     @OsUntrusted
     VerProtocolImpl @OsUntrusted [] result = new @OsUntrusted VerProtocolImpl @OsUntrusted [i];
     System.arraycopy(resultk, 0, result, 0, i);
     return result;
   }
   
   @OsUntrusted
   VerProtocolImpl getHighestSupportedProtocol(RPC.@OsUntrusted Server this, @OsUntrusted RpcKind rpcKind, 
       @OsUntrusted
       String protocolName) {    
     @OsUntrusted
     Long highestVersion = 0L;
     @OsUntrusted
     ProtoClassProtoImpl highest = null;
     if (LOG.isDebugEnabled()) {
       LOG.debug("Size of protoMap for " + rpcKind + " ="
           + getProtocolImplMap(rpcKind).size());
     }
     for (Map.@OsUntrusted Entry<@OsUntrusted ProtoNameVer, @OsUntrusted ProtoClassProtoImpl> pv : 
           getProtocolImplMap(rpcKind).entrySet()) {
       if (pv.getKey().protocol.equals(protocolName)) {
         if ((highest == null) || (pv.getKey().version > highestVersion)) {
           highest = pv.getValue();
           highestVersion = pv.getKey().version;
         } 
       }
     }
     if (highest == null) {
       return null;
     }
     return new @OsUntrusted VerProtocolImpl(highestVersion,  highest);   
   }
  
    protected @OsUntrusted Server(@OsUntrusted String bindAddress, @OsUntrusted int port, 
                     @OsUntrusted
                     Class<@OsUntrusted ? extends @OsUntrusted Writable> paramClass, @OsUntrusted int handlerCount,
                     @OsUntrusted
                     int numReaders, @OsUntrusted int queueSizePerHandler,
                     @OsUntrusted
                     Configuration conf, @OsUntrusted String serverName, 
                     @OsUntrusted
                     SecretManager<@OsUntrusted ? extends @OsUntrusted TokenIdentifier> secretManager,
                     @OsUntrusted
                     String portRangeConfig) throws IOException {
      super(bindAddress, port, paramClass, handlerCount, numReaders, queueSizePerHandler,
            conf, serverName, secretManager, portRangeConfig);
      initProtocolMetaInfo(conf);
    }
    
    private void initProtocolMetaInfo(RPC.@OsUntrusted Server this, @OsUntrusted Configuration conf) {
      RPC.setProtocolEngine(conf, ProtocolMetaInfoPB.class,
          ProtobufRpcEngine.class);
      @OsUntrusted
      ProtocolMetaInfoServerSideTranslatorPB xlator = 
          new @OsUntrusted ProtocolMetaInfoServerSideTranslatorPB(this);
      @OsUntrusted
      BlockingService protocolInfoBlockingService = ProtocolInfoService
          .newReflectiveBlockingService(xlator);
      addProtocol(RpcKind.RPC_PROTOCOL_BUFFER, ProtocolMetaInfoPB.class,
          protocolInfoBlockingService);
    }
    
    /**
     * Add a protocol to the existing server.
     * @param protocolClass - the protocol class
     * @param protocolImpl - the impl of the protocol that will be called
     * @return the server (for convenience)
     */
    public @OsUntrusted Server addProtocol(RPC.@OsUntrusted Server this, @OsUntrusted RpcKind rpcKind, @OsUntrusted Class<@OsUntrusted ? extends java.lang.@OsUntrusted Object> protocolClass,
        @OsUntrusted
        Object protocolImpl) {
      registerProtocolAndImpl(rpcKind, protocolClass, protocolImpl);
      return this;
    }
    
    @Override
    public @OsUntrusted Writable call(RPC.@OsUntrusted Server this, RPC.@OsUntrusted RpcKind rpcKind, @OsUntrusted String protocol,
        @OsUntrusted
        Writable rpcRequest, @OsUntrusted long receiveTime) throws Exception {
      return getRpcInvoker(rpcKind).call(this, protocol, rpcRequest,
          receiveTime);
    }
  }
}
